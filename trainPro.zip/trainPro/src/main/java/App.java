import com.alibaba.fastjson.JSON;
import com.uu.bean.PersonJavaObj;
import com.uu.bean.PersonOuterClass;
import com.uu.util.GetKafkaObj;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Date;

public class App {
    public static void main(String[] args) {
    new App().testJson();

    }
    public void testKafka(){
        //kafka发送数据
        KafkaProducer<Object, Object> kafkaObj = GetKafkaObj.getKafkaObj();
//        (String topic, Integer partition, Long timestamp, K key, V value, Iterable< Header > headers)
        String topic = "train";
        Integer partiton = new Integer(1);
        long timeStamp = new Date().getTime();
        String K = "train----key";
        String V = "train----value";
        ProducerRecord<Object, Object> sendInfo = new ProducerRecord<Object, Object>(topic, partiton, timeStamp, K, V);
        kafkaObj.send(sendInfo);
//        kafkaObj.send(new ProducerRecord<Object, Object>("train","hello"));
        kafkaObj.close();
    }

    public void testJson(){
        PersonJavaObj personJavaObj = new PersonJavaObj("jj", 1, "1@33", "out");
        System.out.println(JSON.toJSONString(personJavaObj));
    }
}
