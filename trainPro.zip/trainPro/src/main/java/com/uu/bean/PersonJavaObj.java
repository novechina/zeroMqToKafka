package com.uu.bean;

import org.apache.kafka.common.protocol.types.Field;

public class PersonJavaObj {
    private String name;
    private int id;
    private String e_mail;
    private String friend;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    public String getFriend() {
        return friend;
    }

    public void setFriend(String friend) {
        this.friend = friend;
    }

    public PersonJavaObj(String name, int id, String e_mail, String friend) {
        this.name = name;
        this.id = id;
        this.e_mail = e_mail;
        this.friend = friend;
    }
}
