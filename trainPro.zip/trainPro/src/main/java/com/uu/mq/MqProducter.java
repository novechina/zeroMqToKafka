package com.uu.mq;

import com.uu.bean.PersonOuterClass;
import com.uu.probuf.ProbufUtils;
import com.uu.util.DateCreat;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

public class MqProducter {
    public static void main(String[] args) throws InterruptedException {
        ZContext zContext = new ZContext();
        /*
         * 生产消息的对象
         *
         * */
        ZMQ.Socket pubSocket = zContext.createSocket(SocketType.PUB);
        pubSocket.bind("tcp://localhost:5556");
        while (true){
            //构建序列化对象
            PersonOuterClass.Person.Builder personBuilder = PersonOuterClass.Person.newBuilder();
            //循环发送
            for (int i = 0 ;i < 7;i++){
                personBuilder.setName(DateCreat.getName());
                personBuilder.setEmail(DateCreat.getEmail());
                personBuilder.setId(i);
//                personBuilder.setFriends(0,DateCreat.getFriend());
                //获取序列化对象
                byte[] serialize = ProbufUtils.serialize(personBuilder);
                System.out.println("send");
                //发送数据
                pubSocket.send(serialize,0);
            }

            Thread.sleep(1000);
        }
    }
}
