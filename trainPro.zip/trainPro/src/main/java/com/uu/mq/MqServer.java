package com.uu.mq;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

public class MqServer {
    public static void main(String[] args) {
        ZContext zContext = new ZContext();
        /*
         * 服务中间端
         * 订阅并分发节点
         * */
        //  订阅对象
        org.zeromq.ZMQ.Socket frontend = zContext.createSocket(SocketType.SUB);
        frontend.connect("tcp://localhost:5556");

        //  发布对象
        org.zeromq.ZMQ.Socket backend = zContext.createSocket(SocketType.PUB);
        backend.bind("tcp://localhost:5555");

        //  订阅内容
        frontend.subscribe(org.zeromq.ZMQ.SUBSCRIPTION_ALL);

        //  开启代理
        ZMQ.proxy(frontend, backend, null);
    }
}
