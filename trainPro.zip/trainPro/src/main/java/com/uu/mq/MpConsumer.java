package com.uu.mq;

import com.uu.probuf.ProbufUtils;
import com.uu.util.GetKafkaObj;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

public class MpConsumer {
    public static void main(String[] args) {
        ZContext zContext = new ZContext();
        //订阅 消息
        ZMQ.Socket subSocket = zContext.createSocket(SocketType.SUB);
        subSocket.connect("tcp://localhost:5555");
        //指定订阅内容
        subSocket.subscribe("".getBytes(ZMQ.CHARSET));

        //接收发送到kafka
        //创建kaka生产者
        KafkaProducer<Object, Object> kafkaObj = GetKafkaObj.getKafkaObj();
        while (true){
            //接受消息并反序列化为json对象
            byte[] recv = subSocket.recv(0);
            String s = ProbufUtils.deSerialize(recv);
            System.out.println(s);
            //推送kafka
            kafkaObj.send(new ProducerRecord<Object, Object>("train",s));
        }
    }
}
