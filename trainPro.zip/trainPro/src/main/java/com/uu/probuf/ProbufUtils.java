package com.uu.probuf;

import com.alibaba.fastjson.JSON;
import com.uu.bean.PersonJavaObj;
import com.uu.bean.PersonOuterClass;
import com.uu.util.DateCreat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ProbufUtils {
    //序列化Person对象
    public static byte[] serialize(PersonOuterClass.Person.Builder person){
        PersonOuterClass.Person buildObj = person.build();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] bytes = null;
        try {
            buildObj.writeTo(output);
            bytes = output.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bytes;
    }

    //反序列化并转为json
    public static String deSerialize(byte[] personByte){
        String info = "";
        ByteArrayInputStream input = new ByteArrayInputStream(personByte);
        try {
            PersonOuterClass.Person person = PersonOuterClass.Person.parseFrom(input);
            String name = person.getName();
            String email = person.getEmail();
            int id = person.getId();
            String friends = DateCreat.getFriend();
            PersonJavaObj personJavaObj = new PersonJavaObj(name, id, email, friends);
            info= JSON.toJSON(personJavaObj).toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return info;
    }

}
