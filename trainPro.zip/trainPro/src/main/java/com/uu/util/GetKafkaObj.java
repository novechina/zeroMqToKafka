package com.uu.util;

import kafka.Kafka;
import org.apache.kafka.clients.producer.KafkaProducer;

import java.util.Properties;

public class GetKafkaObj {
    public static KafkaProducer<Object, Object> getKafkaObj(){
        //构建kafak配置对象
        Properties props = new Properties();
        props.put("bootstrap.servers", "hadoop01:9092");
        props.put("acks", "all");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        KafkaProducer<Object, Object> objectObjectKafkaProducer = new KafkaProducer<>(props);

        return objectObjectKafkaProducer;
    }

}
