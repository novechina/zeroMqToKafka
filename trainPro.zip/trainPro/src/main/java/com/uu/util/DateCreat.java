package com.uu.util;

import java.util.Random;

public class DateCreat {
    public static final char[] emialArray = {'a','b','d','1','3','f'};
    public static final String[] namArray = {"坤","幂","热","丽"};
    public static final String[] friendArray = {"坤","幂","热","丽"};
    public static String getName(){
        int i = new Random().nextInt(namArray.length);
        int i1 = new Random().nextInt(namArray.length);
        return namArray[i]+namArray[i1];
    }
    public static String getEmail(){
        int i = new Random().nextInt(emialArray.length);
        int i1 = new Random().nextInt(emialArray.length);
        return emialArray[i]+emialArray[i1]+"";
    }
    public static String getFriend(){
        int i = new Random().nextInt(friendArray.length);
        int i1 = new Random().nextInt(friendArray.length);
        return friendArray[i]+friendArray[i1];
    }
}
